const express = require("express");
const router = express.Router();

// POST: receive order
router.post("/", (req, res) => {
    const { item, quantity } = req.body;

    console.log("Order received:", item, quantity);

    res.json({
        message: "Order placed successfully",
        order: { item, quantity }
    });
});

module.exports = router;
