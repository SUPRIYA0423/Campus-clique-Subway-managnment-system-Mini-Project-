exports.createOrder = (req, res) => {
    const data = req.body;

    res.json({
        message: "Order saved",
        data
    });
};
