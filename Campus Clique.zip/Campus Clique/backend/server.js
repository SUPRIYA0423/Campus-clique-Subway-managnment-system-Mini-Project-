const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

// ✅ PRODUCTS API
app.get("/products", (req, res) => {
    res.json([
        { name: "Burger", price: 80 },
        { name: "Pizza", price: 120 },
        { name: "Biryani", price: 150 }
    ]);
});

const fs = require("fs");
const path = require("path");

// ✅ ORDERS API (FIXED)
app.post("/api/orders", (req, res) => {
    const { name, item, quantity,price, total, notes } = req.body;

    const order = `${name},${item},${quantity}${price},${total},${notes}\n`;

    // ✅ correct file path (VERY IMPORTANT)
    const filePath = path.join(__dirname, "orders.csv");

    fs.appendFile(filePath, order, (err) => {
        if (err) {
            console.error("Error saving order:", err);
            return res.status(500).json({ message: "Error saving order" });
        }

        console.log("Order saved:", name, item);

        res.json({
            message: "Order placed and saved successfully"
        });
    });
});
app.post("/api/orders", (req, res) => {
    const { type, name, item, quantity, price, total, notes } = req.body;

    const order = `${type},${name},${item},${quantity},${price},${total},${notes}\n`;

    const filePath = path.join(__dirname, "orders.csv");

    fs.appendFile(filePath, order, (err) => {
        if (err) {
            return res.status(500).json({ message: "Error saving order" });
        }

        console.log(`${type} order saved:`, name, item);

        res.json({
            message: `${type} order placed successfully`
        });
    });
});



// ✅ SERVER
app.listen(3000, () => {
    console.log("Server running on port 3000");
});
